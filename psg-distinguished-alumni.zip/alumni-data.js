// Auto-generated PSGIM Distinguished Alumni Data
const ALUMNI_DATA = [
  {
    "id": 1,
    "name": "Mr. Sashikanth Karipineni",
    "position": "Executive Director - Sri Bhavani Castings Limited Director - Saka Organics",
    "description": "MBA 1994 - 1996 / DA Awardee - 2026",
    "year": 2026,
    "batch": "1994 - 1996",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/P-4-rtq5psylscgbo0xa8omzjgehthitotzph9qgjtkz18.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1990s",
    "company": "Saka Organics"
  },
  {
    "id": 2,
    "name": "Mr. N. Viswanath",
    "position": "Director - RMKV",
    "description": "MBA 1992 - 1994 / DA Awardee - 2026",
    "year": 2026,
    "batch": "1992 - 1994",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/P-3-rtq5nbnxr32312izq41fgkxpdvqydl57gzrbyj9dgc.png",
    "sector": "Retail, FMCG & Textiles",
    "decade": "1990s",
    "company": "RMKV",
    "profile": {
      "about": "With an engineering degree and a post-graduation in management from PSG, Mr. N. Viswanath is a Director at RmKV Group, a 90-year-old heritage silk sari brand with stores across Tirunelveli, Chennai, Coimbatore, Bangalore, and an online portal. He leads RmKV's ongoing innovation in colours, designs, and handwoven fabrics crafted by master weavers.",
      "contribution": "Committed to societal benefits and weaver welfare, RmKV works closely at the grassroots weaver level to preserve traditional art and handloom heritage while fostering an employee-centric culture. Mr. Viswanath is also an active member of the Rotary Club, Tirunelveli West."
    }
  },
  {
    "id": 3,
    "name": "Ms. Uma Sekar",
    "position": "Managing Director - Avaneetha Textiles P Ltd & Abikiran Agrofarms P Ltd",
    "description": "MBA 1992 - 1994 / DA Awardee - 2026",
    "year": 2026,
    "batch": "1992 - 1994",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/P-2-rtq5m5d77jg6im8fl3r7udlynjjfr7hab6ehd3038c.png",
    "sector": "Retail, FMCG & Textiles",
    "decade": "1990s",
    "company": "Avaneetha Textiles P Ltd & Abikiran Agrofarms P Ltd"
  },
  {
    "id": 4,
    "name": "Mr. George Thayyil",
    "position": "Managing Director - Johns Group of Companies",
    "description": "MBA 1991 - 1993 / DA Awardee - 2026",
    "year": 2026,
    "batch": "1991 - 1993",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/P-1-rtq5jifi19u7y02bzgpwcjkenmjd5s0ea4ifw4wuos.png",
    "sector": "Retail, FMCG & Textiles",
    "decade": "1990s",
    "company": "Johns Group of Companies",
    "profile": {
      "about": "A third-generation entrepreneur from Alleppey, Mr. George Thayyil completed his MBA at PSG in 1993 and internationalized his family business, Johns Umbrella Mart, expanding into Russia, China, Sri Lanka, and the UAE. In 2000, he diversified into the automobile sector with a Honda Motorcycles and Scooters India (HMSI) dealership. He also established India's largest quality umbrella manufacturing unit in Shengottai, Tamil Nadu in 2008.",
      "contribution": "An active member of social service organizations including Round Table India, Lions, and Rotary. Under his chairmanship, the Round Table of Alleppey won numerous awards for community service and club activities."
    }
  },
  {
    "id": 5,
    "name": "Mr. STANY POTHEN",
    "position": "Former Vice Chairman, Spices Board India, Chairman Cardamom Planters Federation, Member of Plantation Business Advisory Committee, Govt of Kerala",
    "description": "MBA 1997 - 1999 / DA Awardee - 2025",
    "year": 2025,
    "batch": "1997 - 1999",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Mr.-Stany-Pothen-rbvvgigf97u5uw8s559shisqknjdmbk9xefcix9wt8.png",
    "sector": "Public Service & Governance",
    "decade": "1990s",
    "company": "Govt of Kerala"
  },
  {
    "id": 6,
    "name": "Mr. T RAJKUMAR",
    "position": "Chairman, CITI Standing Committee on Cotton, (CITI-CDRA), New Delhi",
    "description": "Director, Sakthi Group of Companies, Cbe MBA 1989 - 1991 / DA Awardee - 2025",
    "year": 2025,
    "batch": "1989 - 1991",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Mr.-T-Rajkumar-rbvvgl9xtpy0tq4oooho7034ct5h9evgxsdsyr5qak.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1980s",
    "company": "New Delhi",
    "profile": {
      "about": "Mr. T. Rajkumar is a dynamic and versatile industrialist based in Coimbatore. He is the Chairman of Sri Mahasakthi Mills Limited, Foundation One Infrastructures Pvt. Ltd., the Southern India Mills' Association (Coimbatore) and the SIMA Cotton Development & Research Association (SIMA CDRA). He is the Vice Chairman of the Confederation of Indian Textile Industry (CITI), New Delhi. He is also a member of the governing council of NGM College, Pollachi and PPG College of Technology. He is a Member of the Academic Council of PSG College of Arts and Science and a member in the Board of Studies of Bharathiar University and PSG Institute of Management. He is the Secretary of Nachimuthu Gounder Rukmani Ammal Charitable Trust and Joint Secretary of Sri Purandaradasar Sangeetha Vidyalaya (Coimbatore), a social and cultural organization dedicated to the cause of development of Arts and Music.",
      "experiences": [
        {
          "role": "Chairman",
          "company": "Foundation One Infrastructures Pvt. Ltd.",
          "period": "2008 – Present",
          "location": "Coimbatore, Tamil Nadu, India",
          "url": "https://foundation1.in/"
        },
        {
          "role": "Chairman",
          "company": "Sri Mahasakthi Mills Limited",
          "period": "1995 – Present",
          "location": "Coimbatore, Tamil Nadu, India",
          "url": "https://mahasakthi.com/"
        }
      ],
      "associatedOrgs": [
        {
          "org": "National Skill Development Corporation (NSDC)",
          "role": "Former Director · 2019 – Present; Director in NSDC and NSDC International (2019 – 2024)"
        },
        {
          "org": "The Southern India Mills' Association (SIMA)",
          "role": "Chairman · 2013 – 2015"
        },
        {
          "org": "SIMA Cotton Development Research Association (SIMA CDRA)",
          "role": "Chairman · 2012 – 2014"
        }
      ],
      "contribution": "He served as member of Cotton Advisory Board and Cotton Yarn Advisory Board for more than five years, when he worked towards enhancing cotton crop production and forecasting, and yarn exports. He was the Chairman of Arulmigu Masani Amman Temple and Charities, Annamalai, for over four years, during which the temple underwent major renovations at a cost of Rs. 10 crore. He is also a member of Textile Export Promotion Council. They manage two schools that cater to underprivileged children.",
      "coimbatoreConnect": "Coimbatore has not only been a forerunner in entrepreneurial development but also a place where many agricultural families have diversified into business. This gave him the confidence to branch out into business, as a first generation entrepreneur.",
      "voiceForYouth": "He dreams of becoming an entrepreneur. He believes it would give him immense satisfaction, as he would be able to provide employment opportunities to many people while contributing to the creation of wealth for the nation."
    }
  },
  {
    "id": 7,
    "name": "Mr. ADKA K. SREESH",
    "position": "CEO, Ideal Stores",
    "description": "MBA 1987 - 1989 / DA Awardee - 2025",
    "year": 2025,
    "batch": "1987 - 1989",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Adka-K.-Sreesh-rbvvfvwap6za495jsviqtohobemkhl2puarp0a7cyk.png",
    "sector": "Retail, FMCG & Textiles",
    "decade": "1980s",
    "company": "Ideal Stores"
  },
  {
    "id": 8,
    "name": "Mr. T VELSANKAR",
    "position": "Chairman, The Vikasa Group of Schools",
    "description": "MBA 1975 - 1977 / DA Awardee - 2025",
    "year": 2025,
    "batch": "1975 - 1977",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/T-Velsankar-rbvvhor5srg2dcjca5k03q4hazqw8p8737s74dj718.png",
    "sector": "Education & Academia",
    "decade": "1970s",
    "company": "The Vikasa Group of Schools"
  },
  {
    "id": 9,
    "name": "Mr. J Jayabalaji",
    "position": "Dy. Financial Advisor & Chief Accounts, Officer / Traffic / South Western Railway",
    "description": "MBA 1998 - 2000 / DA Awardee - 2024",
    "year": 2024,
    "batch": "1998 - 2000",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/JayaBalaji-rbvvg4cuepav0qt9fh6dy4ctnvgvev0avgn2brutek.png",
    "sector": "Public Service & Governance",
    "decade": "1990s",
    "company": "Officer / Traffic / South Western Railway",
    "profile": {
      "about": "A national-level tennis player and 2000 batch PSGIM alumnus, Mr. J. Jayabalaji cleared the Civil Services Examination in 2008 and joined the Indian Railway Accounts Service (IRAS), winning the 'Best Probationer Award' at NAIR, Vadodara. He serves as Assistant Financial Advisor in the Ministry of Railways.",
      "coimbatoreConnect": "Coimbatore's status as one of the highest revenue-generating districts in Tamil Nadu is driven by the entrepreneurial spirit of its people. He attributes much of his success to this wonderful city and its kind-hearted people.",
      "voiceForYouth": "Be clear about what you want in life and work cheerfully towards it. Play a sport, any sport — it helps."
    }
  },
  {
    "id": 10,
    "name": "Ms. Veena Sethuraman",
    "position": "Author, Vice President & Head - Learning and Organizational Development at InMobi",
    "description": "MBA 2001 - 2003 / DA Awardee - 2024",
    "year": 2024,
    "batch": "2001 - 2003",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Veena-Sethuraman-rbvviyt93n7468oft7gpzwi2evfvpvb1ljqzmxmwkc.png",
    "sector": "Technology & Digital",
    "decade": "2000s",
    "company": "Learning and Organizational Development at InMobi"
  },
  {
    "id": 11,
    "name": "Mr. Gunasekaran Krishnan",
    "position": "Co Founder & Director, Ecaps Computer India Pvt. Ltd.,",
    "description": "MBA 1996 - 1998 / DA Awardee - 2024",
    "year": 2024,
    "batch": "1996 - 1998",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Gunasekaran-Krishnan-rbvvfznngj4fep036x593njioy41cdhn6tdmxe1s9o.png",
    "sector": "Technology & Digital",
    "decade": "1990s",
    "company": "Ecaps Computer India Pvt. Ltd.,",
    "profile": {
      "about": "A first-generation entrepreneur from Vellore, Mr. Gunasekaran Krishnan pursued his B.Sc. Computer Science at PSGCT and a part-time MBA at PSGIM. In 1993, alongside three classmates and a capital of Rs. 60,000, he co-founded eCAPS Computer India Pvt. Ltd., growing it into a Rs. 45-crore leader in Computer Networking and Security with over 150 employees across 10+ locations and its own brand 'Netfox'.",
      "contribution": "An active Rotarian and Chairman of 'Mentor a Child', which mentors school students from economically weaker families for six years through Plus-Two. He also served on the management committee of ISODA and represented India in Rotary's Group Study Exchange to South Korea.",
      "voiceForYouth": "When you start a business, stay focused in it for at least a few years to gain an edge over competitors, and reinvest your earnings back into the business."
    }
  },
  {
    "id": 12,
    "name": "Dr. Krishnan Dandapani",
    "position": "Director, College of Business, Dept. of Finance, Florida International University",
    "description": "MBA 1975 - 1977 / DA Awardee - 2024",
    "year": 2024,
    "batch": "1975 - 1977",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Krishnan-Dandapani-rbvvg9zvjpikyel2ijm5d2xl86p2p1mow8jz7fmgd8.png",
    "sector": "Education & Academia",
    "decade": "1970s",
    "company": "Florida International University",
    "profile": {
      "about": "A 1977 PSGIM alumnus, Dr. Krishnan Dandapani earned his Ph.D. in Finance from Pennsylvania State University and has been Professor of Finance at Florida International University (FIU), Miami, for over 30 years. He is the Editor of the Journal of Emerging Financial Markets, author of multiple finance books, and recipient of Florida's Excellence in Research, Teaching, and Service Awards.",
      "coimbatoreConnect": "Coimbatore's entrepreneurial flavour infuses an entrepreneurial spirit into your thinking, action, and work.",
      "voiceForYouth": "At PSGIM you get the best education you need to succeed, and in Coimbatore you learn to be entrepreneurial. There is nothing one cannot achieve if we focus and work towards it — aim beyond the Moon, look at Mars and beyond."
    }
  },
  {
    "id": 13,
    "name": "Mr. Prasanth Subramanian",
    "position": "Co-Founder & Director, Quadra systems India Private Limited",
    "description": "MBA 1996 - 1998 / DA Awardee - 2023",
    "year": 2023,
    "batch": "1996 - 1998",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Prashanth-Subramanian-rbvvgp1al23645z82q46gz4yqcmy47aeaazqvv05lo.png",
    "sector": "Technology & Digital",
    "decade": "1990s",
    "company": "Quadra systems India Private Limited",
    "profile": {
      "about": "Belonging to the 1998 PSGIM batch, Mr. S. Prashanth co-founded Quadrasystems.net (India) Pvt. Ltd. in 2000 alongside P. Nagaraj. Under their leadership, Quadra has become one of India's premier infrastructure software solutions providers, winning 31 global awards from Microsoft (including Worldwide Partner of the Year) and 19 national awards.",
      "contribution": "Mr. Prashanth serves as Convenor of the IT panel of the Confederation of Indian Industry (CII) and Chairman of its flagship ICT event, while co-founder Nagaraj is a founding member of 'Vidiyal', a non-profit supporting the education of needy students.",
      "coimbatoreConnect": "Innovative yet frugal thinking, a quest for excellence, and a passion for success are part of every Coimbatorean's DNA.",
      "voiceForYouth": "Luck is simply being ready to grab an opportunity when it presents itself. Be passionate about what you believe in, focus on execution excellence, and build a loyal team of like-minded people."
    }
  },
  {
    "id": 14,
    "name": "Mr. Rajesh B. Lund",
    "position": "Partner, Srivari Property Developers",
    "description": "MBA 1983 - 1985 / DA Awardee - 2023",
    "year": 2023,
    "batch": "1983 - 1985",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Rajesh-B.-LUND-rbvvhfcrwf3758wzt1hqeshvd5183q6vpx9cblx4rg.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1980s",
    "company": "Srivari Property Developers",
    "profile": {
      "about": "An MBA graduate from PSG, Mr. Rajesh B. Lund joined Srivari Group of Companies in 1985 as a Director, leading business development, marketing, and financial services. His projects 'Srivari Vaibhav' and 'Srivari Ananyaa' earned FIVE STAR ratings from CRISIL. He has served as President of CREDAI (2014–2016) and panel member of CII Coimbatore Zone and Airports Authority of India.",
      "contribution": "Actively involved in charitable trusts and educational institutions as Trustee & Honorary Secretary of Sindhi Samaj Charitable Trust, Honorary Secretary of Sindhi Vidhyalaya Matriculation School, and committee member of Cheshire Homes and RAAC. Awarded 'Sindhu Rathan' in 2012 for his service to society."
    }
  },
  {
    "id": 15,
    "name": "Mrs. Pusphpalata pooranan",
    "position": "Director and Correspondent, Pushpalata Educational Centre",
    "description": "MBA 1995 - 1997 / DA Awardee - 2023",
    "year": 2023,
    "batch": "1995 - 1997",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Pushpalata-Pooranan-rbvvgwk03qdgp1oautd70x8nhflvts48zc7mq2p07w.png",
    "sector": "Education & Academia",
    "decade": "1990s",
    "company": "Pushpalata Educational Centre",
    "profile": {
      "about": "Taking charge as Director and Correspondent of Pushpalata Educational Centre in Tirunelveli in 2003, Mrs. Pushpalata Pooranan expanded the institution from 271 students in one school to 3,712 students across four schools, founding Pushpalata Vidya Mandir (CBSE) in 2008 and Pushpalata British International School (Cambridge) in 2012.",
      "contribution": "In 2012, she launched 'Mitra – Centre for Autism Children', the first school in Tirunelveli dedicated to children with Autism Spectrum Disorder, training them for National Open School examinations and mainstreaming them into society."
    }
  },
  {
    "id": 16,
    "name": "Mr.Bhargav Sundaram",
    "position": "Chief Executive, Callidai Motor Works, Chennai",
    "description": "MBA 1987 - 1989 / DA Awardee - 2023",
    "year": 2023,
    "batch": "1987 - 1989",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Bhargav-Sundaram-q3gmupmma5slhhfg0xf1iw8gmj5eszfwzjkckkf13w.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1980s",
    "company": "Chennai",
    "profile": {
      "about": "Grandson of Enfield India founder Shri K. R. Sundaram Iyer, Mr. Bhargav Sundaram is the Chief Executive of Callidai Motor Works, India's largest manufacturer of powered and special wheelchairs and battery-operated mobility vehicles for persons with neurological and mobility disorders.",
      "contribution": "A pioneer of social entrepreneurship since 1998, over 50% of his workforce (35 of 50+ employees) are differently-abled. He also founded the 'Wheelchair Trust of India' and organizes sports and cultural events for the physically challenged."
    }
  },
  {
    "id": 17,
    "name": "Mr. Ranji Cherian",
    "position": "President & Managing Partner, DDB Mudra India, Bengaluru",
    "description": "MBA 1986 - 1988 / DA Awardee - 2022",
    "year": 2022,
    "batch": "1986 - 1988",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Ranji-Cherian-q3gmtto3tskuiqpv7jlq64asffixj9x1j5du95qezg.png",
    "sector": "Media, Sports & Entertainment",
    "decade": "1980s",
    "company": "Bengaluru",
    "profile": {
      "about": "An alumnus of PSG CAS and PSGIM, Mr. Ranji Cherian is President – South & East at DDB Mudra Group and a Director on the board of DDB Mudra Max. Earlier at JWT India (1993–2007), he led the team that won the global award at the Automotive GBU meet in Detroit (2005). At DDB Mudra, he turned around southern operations into a consistently high-profit region."
    }
  },
  {
    "id": 18,
    "name": "Ms. Pinky Naresh Kumar",
    "position": "Senior Executive Director, EMEA and APAC, Goldman Sachs",
    "description": "MBA 2004 - 2006 / DA Awardee - 2021",
    "year": 2021,
    "batch": "2004 - 2006",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/pic3-q3w3b60jfwpr1764k2f53rwkftq862wf6zo5ni3h3w.png",
    "sector": "Finance & Corporate Leadership",
    "decade": "2000s",
    "company": "Goldman Sachs"
  },
  {
    "id": 19,
    "name": "Mr. Ranjith Nair",
    "position": "Vice President, South East Asia, Air Liquide",
    "description": "MBA 1995 - 1997 / DA Awardee - 2020",
    "year": 2020,
    "batch": "1995 - 1997",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/pic2-q3w30cvcuhx1imvdoe7lfi3qib09ndzjphl4yy4gnw.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1990s",
    "company": "Air Liquide"
  },
  {
    "id": 20,
    "name": "Mr. Ranganathan",
    "position": "COO at Deliver Value.ai, United Kingdom",
    "description": "MBA / DA Awardee - 2019",
    "year": 2019,
    "batch": "",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/pic1-q3w2ox61p29g9fhegg903dzubjdhzyl44vugrr2wd8.png",
    "sector": "Finance & Corporate Leadership",
    "decade": "Other",
    "company": "United Kingdom"
  },
  {
    "id": 21,
    "name": "Mr.K. Shyam sundar",
    "position": "Airline expert, Former CEO, Air India Express",
    "description": "MBA 1978 - 1980 / DA Awardee - 2018",
    "year": 2018,
    "batch": "1978 - 1980",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/pic4-q3w2fnhcavknruy3ky0g0877fr273esej093eitnq4.png",
    "sector": "Enterprise & Leadership",
    "decade": "1970s",
    "company": "Air India Express"
  },
  {
    "id": 22,
    "name": "Mr. Biju Thomas",
    "position": "Mashreq Bank, Dubai, Senior Director & Head of Family Offices",
    "description": "MBA 1991 - 1993 / DA Awardee - 2017",
    "year": 2017,
    "batch": "1991 - 1993",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Mr.Biju-Thomas-2017-q3xq9mj1jg78v66hw0f5sohd2medxtwxc6p9xd3t5o.png",
    "sector": "Finance & Corporate Leadership",
    "decade": "1990s",
    "company": "Senior Director & Head of Family Offices"
  },
  {
    "id": 23,
    "name": "Mr. M.S.P Rama Rao",
    "position": "Managing Director, Konaseema Gas Power Ltd, Hyderabad",
    "description": "MBA 1982 - 1984 / DA Awardee - 2016",
    "year": 2016,
    "batch": "1982 - 1984",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Rama-Rao-q3gmquii6oi5r71il9a99vc8pi735s3n4f0hjm5aos.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1980s",
    "company": "Hyderabad",
    "profile": {
      "about": "A 1984 PSG MBA alumnus, Mr. M.S.P. Rama Rao began his career at Panyam Cements & Mineral Industries Ltd. and went on to become Managing Director of Konaseema Gas Power Ltd. (2000), CEO of VBC Fertilizers & Chemicals Ltd. (2008), and Director of Orissa Power Corporation Ltd. (2009). He also serves on the Governing Body of GITAM University and the Managing Committee of FAPCCI."
    }
  },
  {
    "id": 24,
    "name": "Mr. V. Abdul Razak",
    "position": "Managing Director, VKC Group of Companies, Calicut",
    "description": "MBA 1989 - 1991 / DA Awardee - 2015",
    "year": 2015,
    "batch": "1989 - 1991",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Abdul-q3gmpusmyz59i0hedtufn4cq4v351a5ubi81b3m998.png",
    "sector": "Retail, FMCG & Textiles",
    "decade": "1980s",
    "company": "Calicut",
    "profile": {
      "about": "Mr. V. Abdul Razak is the Managing Director of VKC Group of Companies, India's largest producer of PU footwear. Joining the family business after his MBA at PSGIM in 1992, he helped scale production from 600 pairs to 3.5 lakh pairs a day across 20+ units in five states, employing over 5,000 people with a turnover exceeding Rs. 1,100 crores.",
      "contribution": "Through the 'VKC Charitable Foundation', the group runs two educational institutions providing free education, books, food, and uniforms. He has also served on the Senate of Cochin University of Science and Technology and as Chairman of the Confederation of Indian Footwear Industry (Kerala Region)."
    }
  },
  {
    "id": 25,
    "name": "Mr. M. Settu",
    "position": "Chief Executive Officer, Syndicate Exports Pvt Ltd., Coimbatore",
    "description": "MBA 1980 - 1982 / DA Awardee - 2014",
    "year": 2014,
    "batch": "1980 - 1982",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Settu-q3gmozrypfysuvqgeyfquu6ij5c0z9qp78p0gyw8yk.png",
    "sector": "Enterprise & Leadership",
    "decade": "1980s",
    "company": "Coimbatore",
    "profile": {
      "about": "Securing First Rank with Distinction in his 1982 PSGIM MBA, Mr. M. Settu served Textool Company Ltd. for 10 years before founding Syndicate Exports Pvt. Ltd., exporting chemical and refractory products to over 100 countries. He is also Director General of Sree Saraswathi Thyagaraja College, Fellow of AIMA, former Senate Member of Bharathiar University, and author of two poetry books.",
      "contribution": "Serves as Honorary Director and Management Advisor to numerous industries and educational trusts, and is an active member of CII, ICCI, CODISSIA, and Rotary. He also served as Chairman of the PSG Management Alumni Association for three years."
    }
  },
  {
    "id": 26,
    "name": "Mr. Jayakumar Ramadass",
    "position": "Managing Director, Mahendra Submersible Pumps Pvt, Ltd,Coimbatore",
    "description": "MBA 1983 - 1985 / DA Awardee - 2013",
    "year": 2013,
    "batch": "1983 - 1985",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Jayakumar-q3gmmhjghcj9wbdj1vfk7gy9i5osgbsguu2eeem1jw.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1980s",
    "company": "Ltd,Coimbatore",
    "profile": {
      "about": "An alumnus of PSG CAS and PSGIM, Mr. Jayakumar Ramdass is Managing Director of Mahendra Submersible Pumps Pvt. Ltd. and Mahendra Spinning Mills Pvt. Ltd., Coimbatore, exporting pumps to 25 countries across 4 continents. He is Past President of SIEMA, Past Chairman of CII Coimbatore Zone, and helped bring ELCOT IT Park and direct international flights to Coimbatore.",
      "contribution": "Former National President of Round Table India and Chairman of the Round Table India Foundation, funding community service projects across India. He serves on the Advisory Councils of PSGIM and several colleges, and is President of the Coimbatore District Tennis Association.",
      "experiences": [
        {
          "role": "Managing Director",
          "company": "Mahendra Submersible Pumps Pvt. Ltd.",
          "period": "Present",
          "location": "Coimbatore, Tamil Nadu, India",
          "url": "https://mahendrapumps.com/"
        },
        {
          "role": "Managing Director",
          "company": "Mahendra Spinning Mills Pvt. Ltd.",
          "period": "1991 – Present",
          "location": "Coimbatore, Tamil Nadu, India"
        }
      ],
      "associatedOrgs": [
        {
          "org": "Confederation of Indian Industry (CII)",
          "role": "Past Chairman, Coimbatore Zone & Member, Southern Region / TN State Council"
        },
        {
          "org": "The Southern India Engineering Manufacturers' Association (SIEMA)",
          "role": "Past President"
        },
        {
          "org": "The Institute of Indian Foundrymen (Coimbatore Chapter)",
          "role": "Chairman"
        },
        {
          "org": "Coimbatore Management Association (CMA)",
          "role": "Vice President"
        }
      ]
    }
  },
  {
    "id": 27,
    "name": "Mr. S Muthu Kumar",
    "position": "Officer on Special Duty, Prime Minister's Office, New Delhi",
    "description": "MBA / DA Awardee - 2012",
    "year": 2012,
    "batch": "",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Muthukumar-q3apjzgxcc72o17he98cv3fju4m6vcfgxdiktvqpng.jpg",
    "sector": "Public Service & Governance",
    "decade": "Other",
    "company": "New Delhi"
  },
  {
    "id": 28,
    "name": "Mr. V Lakshminarayanasamy",
    "position": "MD, Suguna Group",
    "description": "MBA 1979 - 1981 / DA Awardee - 2011",
    "year": 2011,
    "batch": "1979 - 1981",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Lakshminarayanaswamy-modified-q3b8emxzq57x4nfejlvd3u8g17mkc6mq8e32lxhx7g.png",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1970s",
    "company": "Suguna Group",
    "profile": {
      "about": "A 1981 MBA alumnus from PSG College of Technology, Mr. V. Lakshminarayanasamy is Managing Director of SUGUNA Group of Industries, a five-decade-old leader in electric motors and pumps exported across India, the Middle East, and SAARC countries. He has served as President of SIEMA, Vice President of ICCIC, and Chairman of the Board of Governors of NIFFT, Ranchi.",
      "contribution": "Instrumental in establishing the Suguna Group of Educational Institutions in Coimbatore — including Suguna PIP School, Suguna Vidyanikethan (a free English-medium school for the economically weak), Suguna Polytechnic College, Suguna College of Engineering, and a community hospital."
    }
  },
  {
    "id": 29,
    "name": "Mr.Jayachandran V.K",
    "position": "Executive Director, Indian Oil Corporation",
    "description": "MBA / DA Awardee - 2010",
    "year": 2010,
    "batch": "",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/vk-jayachandran-q3apk53yhceslozahbo4a20befue5j1uy5fhpjicm4.jpg",
    "sector": "Manufacturing & Infrastructure",
    "decade": "Other",
    "company": "Indian Oil Corporation",
    "profile": {
      "about": "Academically qualified Graduate and PG Diploma holder in Finance Management with 32 years of career success in managing Logistics (Port clearing and Inland transportation), Project Finance, Accounts, and Construction site administration with renowned engineering and manufacturing companies in India and abroad.",
      "experiences": [
        {
          "role": "Logistics Manager",
          "company": "Dangote Industries Limited",
          "period": "Jan 2009 – Sep 2021",
          "location": "Nigeria",
          "url": "https://www.dangote.com/"
        },
        {
          "role": "Accounting Manager",
          "company": "Petron Engineering Construction Limited",
          "period": "Feb 1999 – Apr 2008",
          "location": "Mumbai, Maharashtra, India"
        }
      ]
    }
  },
  {
    "id": 30,
    "name": "MR. Kesavan SRINIVASAN IRS",
    "position": "Ex-Director General, Indian Audit and Accounts Department (CAG India)",
    "description": "MBA 1983 - 1985 / DA Awardee - 2009",
    "year": 2009,
    "batch": "1983 - 1985",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/srinivasan-irs-q3apk2afwuaxmv3dxsg8kkpxma8aifqnxrh19pmj4s.jpg",
    "sector": "Public Service & Governance",
    "decade": "1980s",
    "company": "Indian Audit and Accounts Department (CAG India)",
    "profile": {
      "about": "A 1982 PSGIM MBA alumnus, Mr. Kesavan Srinivasan began his career at TCS before joining the Indian Audit & Accounts Service (C&AG). With nearly three decades of CXO-level government leadership, he served as Principal Accountant General for Tamil Nadu and Puducherry, Principal Director of the Audit Board for 30+ major PSUs, and spent 6 years as Expert/Advisor to the State Audit Institution of the Sultanate of Oman and the United Nations."
    }
  },
  {
    "id": 31,
    "name": "DR. D. J. PANDIAN, IAS",
    "position": "Director General, New Development Bank (NDB) | Former Chief Secretary, Govt. of Gujarat",
    "description": "MBA 1978 - 1980 / DA Awardee - 2008",
    "year": 2008,
    "batch": "1978 - 1980",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/Jagatheesa-Pandian-q3gmhx1p9ca3gk0gqebul4gljq7k1anfw7wfezdxss.png",
    "sector": "Public Service & Governance",
    "decade": "1970s",
    "company": "New Development Bank (NDB)",
    "profile": {
      "about": "Dr. D. J. Pandian (Dharmakkan Jagatheesa Pandian), IAS (1981 batch), is the Director General of the Indian Regional Office of the New Development Bank (NDB), leading high-impact sustainable development projects in India and Bangladesh. With over 35 years of distinguished administrative, financial, and infrastructure leadership, he previously served as Vice President & Chief Investment Officer at the Asian Infrastructure Investment Bank (AIIB) in Beijing, Chief Secretary to the Government of Gujarat, and Advisor to the Executive Director at the World Bank Group in Washington, D.C. He holds a PhD in Energy Security and an MBA.",
      "experiences": [
        {
          "role": "Director General (Indian Regional Office)",
          "company": "New Development Bank (NDB)",
          "period": "Jun 2022 – Present",
          "location": "Gandhinagar, Gujarat, India",
          "url": "https://www.ndb.int/"
        },
        {
          "role": "Vice President & Chief Investment Officer",
          "company": "Asian Infrastructure Investment Bank (AIIB)",
          "period": "Mar 2016 – Mar 2022",
          "location": "Beijing, China",
          "url": "https://www.aiib.org/"
        },
        {
          "role": "Chief Secretary",
          "company": "Government of Gujarat",
          "period": "Oct 2014 – May 2015",
          "location": "Gandhinagar, Gujarat"
        },
        {
          "role": "Additional Chief Secretary (Energy & Petrochemicals / Industries & Mines)",
          "company": "Government of Gujarat",
          "period": "Nov 2009 – Oct 2014",
          "location": "Gandhinagar, Gujarat"
        },
        {
          "role": "Chairman, Standing Committee of the Board of Governors",
          "company": "Pandit Deendayal Petroleum University (PDPU)",
          "period": "Oct 2009 – Feb 2016",
          "location": "Gandhinagar, Gujarat",
          "url": "https://www.pdeu.ac.in/"
        },
        {
          "role": "Managing Director",
          "company": "Gujarat State Petroleum Corporation Ltd. (GSPC)",
          "period": "Oct 2001 – Nov 2009",
          "location": "Gandhinagar, Gujarat",
          "url": "https://gspcgroup.com/"
        },
        {
          "role": "Advisor to the Executive Director",
          "company": "World Bank Group",
          "period": "Jan 1998 – Jan 2001",
          "location": "Washington, D.C., USA",
          "url": "https://www.worldbank.org/"
        },
        {
          "role": "Director (External Commercial Borrowing)",
          "company": "Department of Economic Affairs, Ministry of Finance, Govt. of India",
          "period": "Dec 1994 – Jan 1998",
          "location": "New Delhi, India"
        }
      ],
      "associatedOrgs": [
        {
          "org": "Gujarat Energy Research & Management Institute (GERMI)",
          "role": "Vice Chairman & Managing Trustee (2009 – 2015)"
        },
        {
          "org": "Gujarat Energy & Infrastructure PSUs",
          "role": "Former Chairman / Director — GMDC, GSPC, GSPL, GUVNL, GETCO, Torrent Power & Petronet LNG"
        }
      ],
      "contribution": "Spearheaded Gujarat's transformation from an energy-deficient to an energy-surplus state through power sector reforms, Asia's largest integrated Solar Power Park at Charanka, India's first rooftop solar scheme, and a state-wide gas grid. Played a pivotal role in establishing Pandit Deendayal Petroleum University (PDPU) and GERMI, organizing the Vibrant Gujarat Global Investors Summit 2015, and liberalizing External Commercial Borrowing policies at the Ministry of Finance."
    }
  },
  {
    "id": 32,
    "name": "MR. RADHAKRISHNAN",
    "position": "Politician, Member of Parliament, Puducherry constituency",
    "description": "MBA 1996 - 1998 / DA Awardee - 2007",
    "year": 2007,
    "batch": "1996 - 1998",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/radhakrishnan-q3apk0erj68czn648rmzfl70fihk31j79i62b5pbh8.jpg",
    "sector": "Public Service & Governance",
    "decade": "1990s",
    "company": "Puducherry constituency",
    "profile": {
      "about": "Mr. R. Radhakrishnan is a Member of Parliament representing the Puducherry Lok Sabha constituency (elected in 2014). Earlier, he was twice elected to the Puducherry Legislative Assembly (2001, 2006), served as Chairman of the Pondicherry Slum Clearance Board (2001–2006), and served as Speaker of the Puducherry Assembly (2006–2011)."
    }
  },
  {
    "id": 33,
    "name": "MR. VENKATESH MYSORE",
    "position": "CEO, Kolkata Knight Riders (KKR) and REd Chillies Entertainment Pvt. Ltd",
    "description": "MBA 1983 - 1985 / DA Awardee -2006",
    "year": 2006,
    "batch": "1983 - 1985",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/venkatesh-mysore-final-q3apk464aidia30nmt9hpk8ut1z0xty4m0s089jqsc.jpg",
    "sector": "Media, Sports & Entertainment",
    "decade": "1980s",
    "company": "Kolkata Knight Riders (KKR) and REd Chillies Entertainment Pvt. Ltd",
    "profile": {
      "about": "Mr. Venkatesh S. Mysore ('Venky') is the Chief Executive Officer of Red Chillies Entertainment Pvt. Ltd. and Managing Director of Kolkata Knight Riders (KKR), where he corporatised the franchise and made it profitable. With over 25 years in global insurance and finance, he previously served as Country Head of Sun Life Financial India and MD & CEO of MetLife India Insurance."
    }
  },
  {
    "id": 34,
    "name": "KASI VISWANATHAN K S",
    "position": "Managing Director, Seshasayee Paper and Boards Ltd.,",
    "description": "MBA 1971 - 1973 / DA Awardee - 2005",
    "year": 2005,
    "batch": "1971 - 1973",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/kasi-q3apjxl8yo4i0ta7p8f3q3wmncvgfy80947lvbthzw.jpeg",
    "sector": "Manufacturing & Infrastructure",
    "decade": "1970s",
    "company": "Seshasayee Paper and Boards Ltd.,",
    "profile": {
      "about": "A Chemical Engineer (B.Tech., REC Tiruchi) with an MMS degree from University of Madras, Mr. K. S. Kasi Viswanathan is the Managing Director of Seshasayee Paper and Boards Ltd., bringing nearly 35 years of industrial experience in integrated paper mill management and project implementation. He is an active member of CII and has organized several PaperTech programmes.",
      "experiences": [
        {
          "role": "Managing Director",
          "company": "Seshasayee Paper & Boards Ltd.",
          "period": "Apr 1992 – Present",
          "location": "India",
          "url": "https://www.spbltd.com/"
        },
        {
          "role": "Deputy Managing Director",
          "company": "Seshasayee Paper & Boards Ltd.",
          "period": "Apr 1992 – Present",
          "location": "India"
        }
      ]
    }
  },
  {
    "id": 35,
    "name": "MRS. SAILAJA KIRON",
    "position": "Managing Director, Margadarsi Chit Fund, Hyderabad",
    "description": "MBA 1986 - 1988 / DA Awardee - 2004",
    "year": 2004,
    "batch": "1986 - 1988",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/sailaja--q3apk1clq09nb94r3a1m02yh0wcxaqmxlmtjsfnxb0.jpg",
    "sector": "Finance & Corporate Leadership",
    "decade": "1980s",
    "company": "Hyderabad",
    "profile": {
      "about": "An MBA graduate, Mrs. Sailaja Kiron is the Managing Director of Margadarsi Chit Fund (part of the Eenadu business house), scaling its turnover to Rs. 5,000 crores. She also leads 'Kalanjali', promoting Indian artisans and handicrafts since 1992, and is Director of the women's destination store 'Brisah' in Hyderabad."
    }
  },
  {
    "id": 36,
    "name": "Mr.Thamaraikannan.P IPS",
    "position": "Additional Director General of Public",
    "description": "MBA 1983-1985 / DA Awardee - 2003",
    "year": 2003,
    "batch": "1983-1985",
    "image": "https://psgmaa.com/wp-content/uploads/elementor/thumbs/thamaraikannan-q3apk38a3oc7yh20sauv52he7o3nq4ue9w4iqzl4yk.jpg",
    "sector": "Enterprise & Leadership",
    "decade": "1980s",
    "company": "Additional Director General of Public",
    "profile": {
      "about": "A 1985 PSG MBA alumnus, Mr. P. Thamaraikannan, IPS, joined the Police Service in 1986 and was inducted into the IPS in 1993. He served as Superintendent of Police in Coimbatore and Tiruchi, supervised the 1998 Coimbatore bomb blast case investigation, and served as Inspector General of Police (Administration) in Chennai. He holds a Master's in Applied Criminology from Cambridge University and has received the President's Medal for Gallantry, Meritorious Service, and Distinguished Service."
    }
  }
];

if (typeof module !== 'undefined') {
  module.exports = ALUMNI_DATA;
}
